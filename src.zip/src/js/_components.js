console.log('components');
import "./components/slider"